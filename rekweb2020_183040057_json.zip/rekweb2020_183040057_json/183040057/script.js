let mahasiswa = {
    nama: "Sandhika Galih",
    nrp: "03043023",
    email: "sandhikagalih@unpas.ac.id"
}

console.log(JSON.stringify(mahasiswa));